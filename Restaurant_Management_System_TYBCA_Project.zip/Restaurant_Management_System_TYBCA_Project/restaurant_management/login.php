<?php
require 'config.php';
$role = $_GET['role'] ?? 'customer';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    if ($role === 'admin') {
        $stmt = $conn->prepare("SELECT * FROM admins WHERE username=? AND password=?");
        $stmt->bind_param("ss",$username,$password);
        $stmt->execute(); $res=$stmt->get_result();
        if($row=$res->fetch_assoc()){ $_SESSION['admin']=$row; header("Location: admin.php"); exit; }
    } else {
        $stmt = $conn->prepare("SELECT * FROM customers WHERE email=? AND password=?");
        $stmt->bind_param("ss",$username,$password);
        $stmt->execute(); $res=$stmt->get_result();
        if($row=$res->fetch_assoc()){ $_SESSION['customer']=$row; header("Location: customer.php"); exit; }
    }
    $error='Invalid username/email or password.';
}
?>
<!DOCTYPE html><html><head><title>Login</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container small">
<h2><?=htmlspecialchars(ucfirst($role))?> Login</h2>
<?php if($error): ?><div class="error"><?=$error?></div><?php endif; ?>
<form method="post">
<label><?= $role==='admin'?'Username':'Email' ?></label>
<input name="username" required>
<label>Password</label><input type="password" name="password" required>
<button>Login</button>
</form>
<p>Demo: <?= $role==='admin'?'admin / admin123':'customer@example.com / customer123' ?></p>
</div></body></html>
