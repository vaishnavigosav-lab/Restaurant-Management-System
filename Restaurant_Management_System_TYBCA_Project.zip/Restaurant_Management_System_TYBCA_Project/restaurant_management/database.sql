CREATE DATABASE IF NOT EXISTS restaurant_db;
USE restaurant_db;

CREATE TABLE admins (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) UNIQUE NOT NULL,
 password VARCHAR(255) NOT NULL,
 name VARCHAR(100) NOT NULL
);

CREATE TABLE customers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(120) UNIQUE NOT NULL,
 phone VARCHAR(20),
 password VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE food_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 category_id INT NOT NULL,
 name VARCHAR(120) NOT NULL,
 description VARCHAR(255),
 price DECIMAL(10,2) NOT NULL,
 status ENUM('Available','Unavailable') DEFAULT 'Available',
 FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

CREATE TABLE orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 customer_id INT NOT NULL,
 order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 status ENUM('Pending','Confirmed','Preparing','Ready','Completed','Cancelled') DEFAULT 'Pending',
 total DECIMAL(10,2) DEFAULT 0,
 FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE order_details (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 food_id INT NOT NULL,
 quantity INT NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
 FOREIGN KEY (food_id) REFERENCES food_items(id)
);

CREATE TABLE payments (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 amount DECIMAL(10,2) NOT NULL,
 method ENUM('Cash','UPI','Card') DEFAULT 'Cash',
 payment_status ENUM('Pending','Paid') DEFAULT 'Paid',
 paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

INSERT INTO admins(username,password,name) VALUES
('admin','admin123','System Administrator');

INSERT INTO customers(name,email,phone,password) VALUES
('Demo Customer','customer@example.com','9876543210','customer123');

INSERT INTO categories(name) VALUES
('Starters'),('Main Course'),('Beverages'),('Desserts');

INSERT INTO food_items(category_id,name,description,price,status) VALUES
(1,'Veg Spring Roll','Crispy vegetable rolls',120,'Available'),
(2,'Paneer Biryani','Aromatic rice with paneer',180,'Available'),
(2,'Veg Fried Rice','Fried rice with vegetables',150,'Available'),
(3,'Fresh Lime Soda','Refreshing lime drink',60,'Available'),
(4,'Gulab Jamun','Traditional Indian dessert',80,'Available');
