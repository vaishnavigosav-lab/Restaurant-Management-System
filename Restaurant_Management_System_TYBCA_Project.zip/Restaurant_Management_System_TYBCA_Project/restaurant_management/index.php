<?php require 'config.php'; ?>
<!DOCTYPE html>
<html>
<head><title>Restaurant Management System</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h1>🍽 Restaurant Management System</h1>
<p>Manage menu, customers, orders and billing from one simple system.</p>
<div class="cards">
<a class="card" href="login.php?role=admin">Admin Login</a>
<a class="card" href="login.php?role=customer">Customer Login</a>
</div>
</div>
</body>
</html>
