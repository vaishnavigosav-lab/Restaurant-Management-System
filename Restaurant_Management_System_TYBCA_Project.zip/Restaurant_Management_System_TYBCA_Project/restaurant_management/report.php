<?php
require 'config.php';
if(!isset($_SESSION['admin'])) { header("Location:login.php?role=admin"); exit; }
$q=$conn->query("SELECT DATE(order_date) day, COUNT(*) orders, COALESCE(SUM(total),0) sales FROM orders WHERE status<>'Cancelled' GROUP BY DATE(order_date) ORDER BY day DESC");
?>
<!DOCTYPE html><html><head><title>Sales Report</title><link rel="stylesheet" href="style.css"></head><body>
<div class="container"><div class="top"><h1>Sales Report</h1><a href="admin.php">Dashboard</a></div>
<table><tr><th>Date</th><th>Orders</th><th>Total Sales</th></tr>
<?php while($r=$q->fetch_assoc()): ?><tr><td><?=$r['day']?></td><td><?=$r['orders']?></td><td>₹<?=$r['sales']?></td></tr><?php endwhile; ?></table>
</div></body></html>
