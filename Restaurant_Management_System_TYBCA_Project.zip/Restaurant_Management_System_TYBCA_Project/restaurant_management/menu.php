<?php
require 'config.php';
if(!isset($_SESSION['admin'])) { header("Location:login.php?role=admin"); exit; }
if(isset($_POST['add'])){
    $cat=(int)$_POST['category_id']; $name=trim($_POST['name']); $desc=trim($_POST['description']);
    $price=(float)$_POST['price'];
    $stmt=$conn->prepare("INSERT INTO food_items(category_id,name,description,price) VALUES(?,?,?,?)");
    $stmt->bind_param("issd",$cat,$name,$desc,$price); $stmt->execute();
}
if(isset($_GET['delete'])){ $id=(int)$_GET['delete']; $conn->query("DELETE FROM food_items WHERE id=$id"); }
$cats=$conn->query("SELECT * FROM categories ORDER BY name");
$items=$conn->query("SELECT f.*,c.name category FROM food_items f JOIN categories c ON f.category_id=c.id ORDER BY f.id DESC");
?>
<!DOCTYPE html><html><head><title>Menu</title><link rel="stylesheet" href="style.css"></head><body>
<div class="container"><div class="top"><h1>Menu Management</h1><a href="admin.php">Dashboard</a></div>
<form method="post" class="gridform"><input name="name" placeholder="Food name" required>
<input name="description" placeholder="Description"><input name="price" type="number" step="0.01" placeholder="Price" required>
<select name="category_id" required><?php while($c=$cats->fetch_assoc()): ?><option value="<?=$c['id']?>"><?=$c['name']?></option><?php endwhile; ?></select>
<button name="add">Add Food</button></form>
<table><tr><th>ID</th><th>Name</th><th>Category</th><th>Price</th><th>Action</th></tr>
<?php while($i=$items->fetch_assoc()): ?><tr><td><?=$i['id']?></td><td><?=htmlspecialchars($i['name'])?></td><td><?=$i['category']?></td><td>₹<?=$i['price']?></td>
<td><a href="?delete=<?=$i['id']?>" onclick="return confirm('Delete item?')">Delete</a></td></tr><?php endwhile; ?></table>
</div></body></html>
