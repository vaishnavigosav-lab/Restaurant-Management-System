RESTAURANT MANAGEMENT SYSTEM - TYBCA
Technology: PHP 8+, MySQL, HTML, CSS, Bootstrap-compatible CSS, XAMPP

SETUP:
1. Install XAMPP and start Apache + MySQL.
2. Copy the 'restaurant_management' folder to C:/xampp/htdocs/
3. Open phpMyAdmin and create/import database.sql.
4. Visit http://localhost/restaurant_management/
5. Demo admin: username=admin, password=admin123
6. Demo customer: username=customer, password=customer123

This is an academic/demo project. Change passwords before real deployment.
