<?php
require 'config.php';
if(!isset($_SESSION['admin'])) { header("Location:login.php?role=admin"); exit; }
if(isset($_GET['status'])){ $id=(int)$_GET['id']; $status=$conn->real_escape_string($_GET['status']); $conn->query("UPDATE orders SET status='$status' WHERE id=$id"); }
$q=$conn->query("SELECT o.*,c.name customer FROM orders o JOIN customers c ON o.customer_id=c.id ORDER BY o.id DESC");
?>
<!DOCTYPE html><html><head><title>Orders</title><link rel="stylesheet" href="style.css"></head><body>
<div class="container"><div class="top"><h1>Orders</h1><a href="admin.php">Dashboard</a></div>
<table><tr><th>Order</th><th>Customer</th><th>Date</th><th>Total</th><th>Status</th><th>Update</th></tr>
<?php while($o=$q->fetch_assoc()): ?><tr><td>#<?=$o['id']?></td><td><?=htmlspecialchars($o['customer'])?></td><td><?=$o['order_date']?></td><td>₹<?=$o['total']?></td><td><?=$o['status']?></td>
<td><a href="?id=<?=$o['id']?>&status=Preparing">Preparing</a> | <a href="?id=<?=$o['id']?>&status=Ready">Ready</a> | <a href="?id=<?=$o['id']?>&status=Completed">Completed</a></td></tr><?php endwhile; ?></table>
</div></body></html>
