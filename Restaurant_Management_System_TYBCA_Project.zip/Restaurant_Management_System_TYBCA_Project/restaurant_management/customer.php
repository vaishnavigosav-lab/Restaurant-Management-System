<?php
require 'config.php';
if(!isset($_SESSION['customer'])) { header("Location:login.php?role=customer"); exit; }
$items=$conn->query("SELECT * FROM food_items WHERE status='Available' ORDER BY name");
if(isset($_POST['order'])){
    $food_id=(int)$_POST['food_id']; $qty=max(1,(int)$_POST['quantity']);
    $f=$conn->query("SELECT * FROM food_items WHERE id=$food_id AND status='Available'")->fetch_assoc();
    if($f){
        $total=$f['price']*$qty; $cid=$_SESSION['customer']['id'];
        $conn->query("INSERT INTO orders(customer_id,total) VALUES($cid,$total)");
        $oid=$conn->insert_id;
        $stmt=$conn->prepare("INSERT INTO order_details(order_id,food_id,quantity,price) VALUES(?,?,?,?)");
        $stmt->bind_param("iiid",$oid,$food_id,$qty,$f['price']); $stmt->execute();
        $conn->query("INSERT INTO payments(order_id,amount,method,payment_status) VALUES($oid,$total,'Cash','Paid')");
        $msg="Order #$oid placed successfully.";
    }
}
?>
<!DOCTYPE html><html><head><title>Customer</title><link rel="stylesheet" href="style.css"></head><body>
<div class="container"><div class="top"><h1>Welcome, <?=htmlspecialchars($_SESSION['customer']['name'])?></h1><a href="logout.php">Logout</a></div>
<?php if(isset($msg)): ?><div class="success"><?=$msg?></div><?php endif; ?>
<h2>Available Menu</h2><table><tr><th>Food</th><th>Description</th><th>Price</th><th>Order</th></tr>
<?php while($i=$items->fetch_assoc()): ?><tr><td><?=htmlspecialchars($i['name'])?></td><td><?=$i['description']?></td><td>₹<?=$i['price']?></td>
<td><form method="post"><input type="hidden" name="food_id" value="<?=$i['id']?>"><input name="quantity" type="number" min="1" value="1" style="width:70px"><button name="order">Order</button></form></td></tr><?php endwhile; ?></table>
</div></body></html>
