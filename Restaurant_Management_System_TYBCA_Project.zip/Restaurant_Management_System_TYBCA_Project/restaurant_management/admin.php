<?php
require 'config.php';
if(!isset($_SESSION['admin'])) { header("Location:login.php?role=admin"); exit; }
$food=$conn->query("SELECT COUNT(*) c FROM food_items")->fetch_assoc()['c'];
$orders=$conn->query("SELECT COUNT(*) c FROM orders WHERE DATE(order_date)=CURDATE()")->fetch_assoc()['c'];
$customers=$conn->query("SELECT COUNT(*) c FROM customers")->fetch_assoc()['c'];
$sales=$conn->query("SELECT COALESCE(SUM(total),0) s FROM orders WHERE DATE(order_date)=CURDATE() AND status<>'Cancelled'")->fetch_assoc()['s'];
?>
<!DOCTYPE html><html><head><title>Admin</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<div class="top"><h1>Admin Dashboard</h1><a href="logout.php">Logout</a></div>
<div class="cards">
<div class="card">Food Items<h2><?=$food?></h2></div>
<div class="card">Today's Orders<h2><?=$orders?></h2></div>
<div class="card">Customers<h2><?=$customers?></h2></div>
<div class="card">Today's Sales<h2>₹<?=$sales?></h2></div>
</div>
<h2>Quick Links</h2>
<a class="btn" href="menu.php">Manage Menu</a>
<a class="btn" href="orders.php">View Orders</a>
<a class="btn" href="report.php">Sales Report</a>
</div></body></html>
